class Comment extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            comments : posts.comments
        };

        this.deleteComment = this.deleteComment.bind(this);
    }

    deleteComment(comment,i) {
        console.log(comment);
        console.log(i);
        axios.post("/users/c_delete", {
            commentId: comment, postId:posts._id
        }).then((response) => {
            console.log(response.data.success);
            if (response.data.success == true) {
                this.setState({comments: response.data.comments});
            }
        }).catch((error) => {
            console.log(error);
        });
    }

    createTable = () => {
        var item = [];
        var commentId = [];
        if (this.state.comments) {
            for (var i = 0; i < this.state.comments.length; i++) {
                commentId.push(this.state.comments[i]._id);
                item.push(
                    <div>
                        <h3>{this.state.comments[i].content}</h3>
                        <button onClick={() =>this.deleteComment(commentId,i)}>삭제</button>
                    </div>
                );
            }
        }
        console.log(commentId);
        return item;
    }

    render() {
        return (
            <div>{this.createTable()}</div>
        );
    }
}

class Post extends React.Component {
    render() {
        var updateLink = "/users/post/update/" + posts._id;
        var deleteLink = "/users/post/delete/" + posts._id;
        return (
            <div className="join">
                <Menu/>
                <div className="keyimage">
                    <img src="/images/keyimage2.png"/>
                </div>
                <div className="content">
                    <h3>제목 : {posts.title}</h3>

                    <h3>내용 : {posts.contents}</h3>
                    <button><a href={updateLink}>수정</a></button>
                    <button><a href={deleteLink}>삭제</a></button>
                    <p/>
                    <button><a href="/users/centerPost">목록</a></button>
                    <hr/>
                    <form action="/users/comment" method="post">
                        <h2>댓글</h2>
                        <textarea name="commentContents"></textarea>
                        <input type="hidden" name="id" value={posts._id}/>
                        <input type="submit" value="작성"/>
                    </form>
                    <Comment></Comment>
                </div>
            </div>
        );
    }
}


ReactDOM.render(<Post/>, document.getElementById('post'));
