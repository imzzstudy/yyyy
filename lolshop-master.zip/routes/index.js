var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index');
});

router.get('/champion', function(req, res, next) {
  res.render('champion');
});

router.get('/skin', function(req, res, next) {
  res.render('skin');
});

router.get('/wardSkin', function(req, res, next) {
  res.render('wardSkin');
});

router.get('/serviceCenter', function(req, res, next) {
  res.render('serviceCenter');
});

module.exports = router;
